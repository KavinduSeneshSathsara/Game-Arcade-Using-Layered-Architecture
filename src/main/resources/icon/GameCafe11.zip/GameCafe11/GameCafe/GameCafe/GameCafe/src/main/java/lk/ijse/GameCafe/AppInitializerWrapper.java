package lk.ijse.GameCafe;

public class AppInitializerWrapper {
    public static void main(String[] args) {
        lk.ijse.GameCafe.AppInitializer.main(args);
    }
}
