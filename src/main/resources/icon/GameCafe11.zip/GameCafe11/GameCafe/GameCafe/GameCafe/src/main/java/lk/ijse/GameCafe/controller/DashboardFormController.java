package lk.ijse.GameCafe.controller;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class DashboardFormController {
    public Button btnSupplier  ;
    @FXML
    private AnchorPane root;
    @FXML
    private void navigateToMemberForm() throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/Member_Form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Coworkhub");
        stage.centerOnScreen();
    }
    @FXML
    private void navigateToEmployeeForm() throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/Employee_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Coworkhub");
        stage.centerOnScreen();
    }
    @FXML
    private void navigateToSupplierForm() throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/Supplier_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Coworkhub");
        stage.centerOnScreen();
    }

}
