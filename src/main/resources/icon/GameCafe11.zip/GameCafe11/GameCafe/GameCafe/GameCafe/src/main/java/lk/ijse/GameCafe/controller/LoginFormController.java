package lk.ijse.GameCafe.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.GameCafe.model.UserModel;

import java.io.IOException;

public class LoginFormController {
    @FXML
    private TextField txtUsername;
    @FXML
    private PasswordField txtPw;
    @FXML
    private AnchorPane root;

    @FXML
    public void btnLoginOnAction(javafx.event.ActionEvent actionEvent) {
        String username = txtUsername.getText();
        String password = txtPw.getText();

        try {
            boolean userIsExist = UserModel.isExistUser(username,password);

            if(userIsExist){
               navigateToDashboard();
            }else{
                new Alert(Alert.AlertType.WARNING,"Username and Password is Wrong!").show();
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private void navigateToDashboard() throws IOException{
        Parent rootNode = FXMLLoader.load(this.getClass().getResource("/view/Dashboard_form.fxml"));
        Scene scene = new Scene(rootNode);

        root.getChildren().clear();
        Stage primaryStage = (Stage) root.getScene().getWindow();

        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
        primaryStage.setTitle("Dashboard Form");
    }
    @FXML
    public void registerOnAction(javafx.event.ActionEvent actionEvent) throws IOException {
        Parent rootNode = FXMLLoader.load(this.getClass().getResource("/view/Register_form.fxml"));
        Scene scene = new Scene(rootNode);

        root.getChildren().clear();
        Stage primaryStage = (Stage) root.getScene().getWindow();

        primaryStage.setScene(scene);
        primaryStage.centerOnScreen();
        primaryStage.setTitle("Register Form");
    }
}

