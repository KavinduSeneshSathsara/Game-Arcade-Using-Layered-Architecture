package lk.ijse.GameCafe.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.GameCafe.dto.UserDto;
import lk.ijse.GameCafe.model.UserModel;

import java.io.IOException;

public class RegisterFormController {
    @FXML
    private AnchorPane root;

    @FXML
    private TextField txtUsername2;

    @FXML
    private PasswordField txtPw2;


    public void btnRegisterOnAction(ActionEvent actionEvent) {
        try{
            boolean userCheck = txtUsername2.getText().equals(UserModel.getUserName(txtUsername2.getText()));

            if(!userCheck){

                UserDto userDto = new UserDto();

                userDto.setUsername(txtUsername2.getText());
                userDto.setPassword(txtPw2.getText());

                boolean saved = UserModel.registerUser(userDto);

                if(saved) {
                    new Alert(Alert.AlertType.INFORMATION,"User Registered!").show();
                }else{
                    new Alert(Alert.AlertType.ERROR,"User not Registered!").show();
                }
            }else {
                new Alert(Alert.AlertType.INFORMATION,"Already Registered!").show();
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }

    public void btnLoginOnAction(ActionEvent actionEvent) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/login_form.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = (Stage) root.getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Login Form");
        stage.centerOnScreen();
    }
}
