package lk.ijse.GameCafe.controller;

import javafx.event.ActionEvent;

public class SignupFormController {
    public void btnLoginOnAction(ActionEvent actionEvent) {

    }
}
