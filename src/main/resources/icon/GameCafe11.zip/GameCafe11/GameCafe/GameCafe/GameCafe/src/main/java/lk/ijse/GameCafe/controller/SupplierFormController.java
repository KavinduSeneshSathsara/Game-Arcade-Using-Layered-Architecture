package lk.ijse.GameCafe.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.GameCafe.dto.EmployeeDto;
import lk.ijse.GameCafe.dto.SupplierDto;
import lk.ijse.GameCafe.model.EmployeeModel;
import lk.ijse.GameCafe.model.SupplierModel;

import java.io.IOException;
import java.sql.SQLException;

public class SupplierFormController {
    @FXML
    private AnchorPane root;
    @FXML
    private TextField txt1;
    @FXML
    private TextField txt2;
    @FXML
    private TextField txt3;
    @FXML
    private TextField txt4;


    @FXML
    void clearFields() {
        txt1.setText("");
        txt2.setText("");
        txt3.setText("");
        txt4.setText("");
    }

    public void btnSaveOnAction(javafx.event.ActionEvent actionEvent) {

        String id = txt1.getText();
        String firstName = txt2.getText();
        String lastName = txt3.getText();
        String tel = txt4.getText();

        SupplierDto supplierDto = new SupplierDto();
        supplierDto.setId(id);
        supplierDto.setFirstName(firstName);
        supplierDto.setLastName(lastName);
        supplierDto.setTel(Integer.parseInt(tel));


        try {
            boolean isSaved = SupplierModel.registerSupplier(supplierDto);
            if (isSaved) {
                new Alert(Alert.AlertType.INFORMATION, "Supplier Registered!").show();
                clearFields();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    @FXML
    void btnUpdateOnAction(ActionEvent event) {

        String id = txt1.getText();
        String firstName = txt2.getText();
        String lastName = txt3.getText();
        String tel = txt4.getText();

        SupplierDto supplierDto = new SupplierDto();
        supplierDto.setId(id);
        supplierDto.setFirstName(firstName);
        supplierDto.setLastName(lastName);
        supplierDto.setTel(Integer.parseInt(tel));


        try {

            boolean isUpdated = SupplierModel.updateSupplier(supplierDto);

            if(isUpdated) {
                new Alert(Alert.AlertType.CONFIRMATION, "Supplier updated!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    @FXML
    void btnDeleteOnAction(ActionEvent event) {
        String id = txt1.getText();


        try {
            boolean isDeleted = SupplierModel.deleteSupplier(id);

            if(isDeleted) {
                new Alert(Alert.AlertType.INFORMATION, "Supplier deleted!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    @FXML
    void btnBackOnAction(ActionEvent event) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/Dashboard_form.fxml"));
        Stage stage = (Stage) root.getScene().getWindow();

        stage.setScene(new Scene(anchorPane));
        stage.setTitle("Dashboard");
        stage.centerOnScreen();
    }
}
