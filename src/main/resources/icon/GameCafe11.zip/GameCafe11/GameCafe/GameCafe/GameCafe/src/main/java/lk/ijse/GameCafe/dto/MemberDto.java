package lk.ijse.GameCafe.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class MemberDto {

    private String id;
    private String firstName;
    private String secondName;
    private String lastName;
    private String nic;
    private int tel;
    private String email;
    private String address;
    private String profession;
    private double loyalty;

}
