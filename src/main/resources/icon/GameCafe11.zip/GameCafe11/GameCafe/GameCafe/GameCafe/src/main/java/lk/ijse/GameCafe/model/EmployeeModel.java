package lk.ijse.GameCafe.model;

import lk.ijse.GameCafe.db.DbConnection;
import lk.ijse.GameCafe.dto.EmployeeDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmployeeModel {
    public static boolean registerEmployee(EmployeeDto employeeDto) throws SQLException {

        Connection connection = DbConnection.getInstance().getConnection();

        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO employee VALUES (? , ? , ? , ? , ? )");
        preparedStatement.setObject(1,employeeDto.getId());
        preparedStatement.setObject(2,employeeDto.getFirstName());
        preparedStatement.setObject(3,employeeDto.getLastName());
        preparedStatement.setObject(4,"");
        preparedStatement.setObject(5,employeeDto.getTel());


        boolean isRegistered = preparedStatement.executeUpdate() > 0;

        return isRegistered;
    }

    public static boolean updateEmployee(final EmployeeDto employeeDto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE employee SET id = ?, firstName = ?, lastName = ?, tel = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1,employeeDto.getId());
        preparedStatement.setString(2, employeeDto.getFirstName());
        preparedStatement.setString(3, employeeDto.getLastName());
        preparedStatement.setString(4, String.valueOf(employeeDto.getTel()));
        preparedStatement.setString(5, employeeDto.getId());

        return preparedStatement.executeUpdate() > 0;
    }

    public static  boolean deleteEmployee(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "DELETE FROM employee WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, id);

        return preparedStatement.executeUpdate() > 0;
    }

}
