package lk.ijse.GameCafe.model;

import lk.ijse.GameCafe.db.DbConnection;
import lk.ijse.GameCafe.dto.MemberDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MemberModel {
    public static boolean registerMember(MemberDto memberDto) throws SQLException {

        Connection connection = DbConnection.getInstance().getConnection();

        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO member VALUES (? , ? , ? , ? , ? , ?, ?, ?, ?)");
        preparedStatement.setObject(1,memberDto.getId());
        preparedStatement.setObject(2,memberDto.getFirstName());
        preparedStatement.setObject(3,memberDto.getLastName());
        preparedStatement.setObject(4,"");
        preparedStatement.setObject(5,memberDto.getTel());
        preparedStatement.setObject(6,"");
        preparedStatement.setObject(7,"");
        preparedStatement.setObject(8,"");
        preparedStatement.setObject(9,0.00);



        boolean isRegistered = preparedStatement.executeUpdate() > 0;

        return isRegistered;
    }


    public static boolean updateMember(final MemberDto memberDto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE member SET id = ?, firstName = ?, lastName = ?, tel = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1,memberDto.getId());
        preparedStatement.setString(2, memberDto.getFirstName());
        preparedStatement.setString(3, memberDto.getLastName());
        preparedStatement.setString(4, String.valueOf(memberDto.getTel()));
        preparedStatement.setString(5, memberDto.getId());

        return preparedStatement.executeUpdate() > 0;
    }

    public static  boolean deleteMember(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "DELETE FROM member WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, id);

        return preparedStatement.executeUpdate() > 0;
    }



}
