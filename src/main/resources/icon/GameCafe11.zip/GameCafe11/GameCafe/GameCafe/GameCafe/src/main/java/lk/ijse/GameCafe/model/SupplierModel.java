package lk.ijse.GameCafe.model;

import lk.ijse.GameCafe.db.DbConnection;
import lk.ijse.GameCafe.dto.EmployeeDto;
import lk.ijse.GameCafe.dto.SupplierDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SupplierModel {
    public static boolean registerSupplier(SupplierDto supplierDto) throws SQLException {

        Connection connection = DbConnection.getInstance().getConnection();

        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO supplier VALUES (? , ? , ? , ? , ? )");
        preparedStatement.setObject(1,supplierDto.getId());
        preparedStatement.setObject(2,supplierDto.getFirstName());
        preparedStatement.setObject(3,supplierDto.getLastName());
        preparedStatement.setObject(4,"");
        preparedStatement.setObject(5,supplierDto.getTel());


        boolean isRegistered = preparedStatement.executeUpdate() > 0;

        return isRegistered;
    }

    public static boolean updateSupplier(final SupplierDto supplierDto) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "UPDATE supplier SET id = ?, firstName = ?, lastName = ?, tel = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1,supplierDto.getId());
        preparedStatement.setString(2, supplierDto.getFirstName());
        preparedStatement.setString(3, supplierDto.getLastName());
        preparedStatement.setString(4, String.valueOf(supplierDto.getTel()));
        preparedStatement.setString(5, supplierDto.getId());

        return preparedStatement.executeUpdate() > 0;
    }

    public static  boolean deleteSupplier(String id) throws SQLException {
        Connection connection = DbConnection.getInstance().getConnection();

        String sql = "DELETE FROM supplier WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, id);

        return preparedStatement.executeUpdate() > 0;
    }

}
